config = {
    'MYSQL_DATABASE_USER': 'root',
    'MYSQL_DATABASE_PASSWORD': 'root',
    'MYSQL_DATABASE_DB': 'drawings',
    'MYSQL_DATABASE_HOST': 'localhost',
    'MYSQL_DATABASE_PORT': 8889
}